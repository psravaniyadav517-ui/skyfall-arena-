(() => {
const $ = id => document.getElementById(id);
const screens = ['home','profile','game','result'];
let profile = {name:'Rookie', email:'', coins:250, matches:0, wins:0, kills:0, rewarded:false};
try { profile = {...profile, ...JSON.parse(localStorage.getItem('skyfall-profile')||'{}')}; } catch {}
let selectedChar=0, running=false, raf=0, last=0, elapsed=0, earned=0;
const canvas=$('gameCanvas'), ctx=canvas.getContext('2d');
const W=2000,H=1400;
let player, bots=[], bullets=[], pickups=[], others={}, myId=null, socket=null, online=false;
const keys={}, joy={x:0,y:0}; let mouse={x:480,y:320,down:false};
const looks=[{color:'#c8ff47',accent:'#287e68',glyph:'⚡'},{color:'#ff9b57',accent:'#b84e3e',glyph:'✦'},{color:'#b8c8d8',accent:'#52647a',glyph:'⬟'}];
function save(){localStorage.setItem('skyfall-profile',JSON.stringify(profile)); updateUI();}
function updateUI(){
 $('coins').textContent=profile.coins; $('playerName').textContent=profile.name; $('profileHeading').textContent=profile.name;
 $('profileStatus').textContent=`LEVEL ${1+Math.floor(profile.matches/5)} • LOCAL PROFILE`;
 $('avatar').textContent=looks[selectedChar].glyph; $('avatarBig').textContent=looks[selectedChar].glyph;
 $('matches').textContent=profile.matches; $('wins').textContent=profile.wins; $('kills').textContent=profile.kills;
 $('nameInput').value=profile.name; $('emailInput').value=profile.email||'';
}
function show(id){screens.forEach(s=>$(s).classList.toggle('active',s===id)); if(id!=='game') stopGame(); }
function toast(msg){const t=$('toast');t.textContent=msg;t.style.display='block';clearTimeout(toast.timer);toast.timer=setTimeout(()=>t.style.display='none',1800);}
document.querySelectorAll('[data-back]').forEach(b=>b.onclick=()=>show('home'));
$('profileBtn').onclick=()=>{updateUI();show('profile')};
$('saveProfile').onclick=()=>{profile.name=$('nameInput').value.trim().slice(0,18)||'Rookie';profile.email=$('emailInput').value.trim().slice(0,100);save();toast('Profile saved on this device');};
document.querySelectorAll('.character').forEach(b=>b.onclick=()=>{selectedChar=Number(b.dataset.char);document.querySelectorAll('.character').forEach(x=>x.classList.toggle('selected',x===b));updateUI();});
$('rewardsBtn').onclick=()=>{if(profile.rewarded){toast('Daily reward already claimed');return;}profile.rewarded=true;profile.coins+=50;save();toast('Daily reward claimed: +50 coins!');};
$('connectBtn').onclick=()=>{if(socket&&socket.readyState===1){socket.close();return;} connectOnline();};
function connectOnline(){
 const url=prompt('Enter multiplayer server URL (for example ws://192.168.1.20:8081). Leave blank to cancel:','ws://localhost:8081');
 if(!url)return;
 try{socket=new WebSocket(url);}catch(e){toast('Invalid server URL');return;}
 socket.onopen=()=>{online=true;$('connectBtn').textContent='ONLINE: CONNECTED';toast('Connected to relay server');};
 socket.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch{return;}
 if(m.type==='welcome'){myId=m.id;(m.players||[]).forEach(p=>{if(p.id!==myId)others[p.id]=p;});}
 if(m.type==='join'&&m.player.id!==myId)others[m.player.id]=m.player;
 if(m.type==='state'&&m.player.id!==myId)others[m.player.id]=m.player;
 if(m.type==='leave')delete others[m.id];};
 socket.onclose=()=>{online=false;myId=null;others={};$('connectBtn').textContent='ONLINE: OFFLINE';toast('Multiplayer disconnected');};
 socket.onerror=()=>toast('Could not connect — check server URL');
}
$('trainingBtn').onclick=()=>startGame(true);
$('playBtn').onclick=()=>startGame(false);
$('againBtn').onclick=()=>startGame(false);
$('leaveBtn').onclick=()=>finish(false,true);
function rand(a,b){return a+Math.random()*(b-a)}
function startGame(training){
 show('game');running=true;elapsed=0;last=0;earned=0;mouse.down=false;
 player={x:W/2,y:H/2,hp:100,ammo:30,maxAmmo:30,angle:0,speed:240,fireCd:0,medkits:1};
 bots=Array.from({length:training?4:11},(_,i)=>({id:i,x:rand(150,W-150),y:rand(150,H-150),hp:100,angle:rand(0,6.28),speed:rand(65,105),fireCd:rand(.2,1.5),think:rand(.4,1.5),color:['#f47b59','#b5d9e8','#c1a1f2'][i%3]}));
 bullets=[];pickups=Array.from({length:35},()=>({x:rand(70,W-70),y:rand(70,H-70),type:Math.random()<.55?'ammo':'med',taken:false}));
 $('health').textContent=100;$('ammo').textContent=30;$('alive').textContent=bots.length+1;
 toast(training?'Training match — bots are active':'Match started — survive the safe zone!');
 cancelAnimationFrame(raf);raf=requestAnimationFrame(loop);
}
function stopGame(){running=false;cancelAnimationFrame(raf);mouse.down=false;}
function fire(from,angle,owner){if(from.fireCd>0)return;if(owner==='player'&&player.ammo<=0){toast('Out of ammo — reload');return;}
 if(owner==='player')player.ammo--;from.fireCd=owner==='player'?.18:rand(.65,1.3);
 bullets.push({x:from.x+Math.cos(angle)*22,y:from.y+Math.sin(angle)*22,vx:Math.cos(angle)*650,vy:Math.sin(angle)*650,life:1.4,owner,damage:owner==='player'?34:8});
}
function loop(ts){if(!running)return;const dt=Math.min((ts-last)/1000||0,0.04);last=ts;elapsed+=dt;update(dt);draw();raf=requestAnimationFrame(loop);}
function update(dt){
 const moveX=(keys.d||keys.ArrowRight?1:0)-(keys.a||keys.ArrowLeft?1:0)+joy.x;
 const moveY=(keys.s||keys.ArrowDown?1:0)-(keys.w||keys.ArrowUp?1:0)+joy.y;
 const mag=Math.hypot(moveX,moveY)||1;player.x=Math.max(25,Math.min(W-25,player.x+moveX/mag*player.speed*dt));player.y=Math.max(25,Math.min(H-25,player.y+moveY/mag*player.speed*dt));
 const cam=camera();const mx=mouse.x/canvas.clientWidth*canvas.width+cam.x, my=mouse.y/canvas.clientHeight*canvas.height+cam.y;
 player.angle=Math.atan2(my-player.y,mx-player.x);
 if(mouse.down||keys[' '])fire(player,player.angle,'player');
 player.fireCd=Math.max(0,player.fireCd-dt);
 for(const b of bots){
  b.fireCd-=dt;b.think-=dt;const dx=player.x-b.x,dy=player.y-b.y,d=Math.hypot(dx,dy)||1;
  if(b.think<=0){b.angle=Math.atan2(dy,dx)+rand(-.9,.9);b.think=rand(.5,1.4);}
  if(d>180){b.x+=Math.cos(b.angle)*b.speed*dt;b.y+=Math.sin(b.angle)*b.speed*dt;}else if(d<90){b.x-=Math.cos(b.angle)*b.speed*.55*dt;b.y-=Math.sin(b.angle)*b.speed*.55*dt;}
  b.x=Math.max(20,Math.min(W-20,b.x));b.y=Math.max(20,Math.min(H-20,b.y));
  if(d<520&&Math.random()<.018)fire(b,Math.atan2(dy,dx)+rand(-.15,.15), 'bot');
 }
 for(const q of bullets){q.x+=q.vx*dt;q.y+=q.vy*dt;q.life-=dt;
  if(q.owner==='player'){for(const b of bots){if(b.hp>0&&Math.hypot(q.x-b.x,q.y-b.y)<20){b.hp-=q.damage;q.life=0;if(b.hp<=0){profile.kills++;profile.coins+=5;earned+=5;toast('Elimination +5 coins');}break;}}}
  else if(Math.hypot(q.x-player.x,q.y-player.y)<20){player.hp-=q.damage;q.life=0;}
 }
 bullets=bullets.filter(b=>b.life>0&&b.x>0&&b.y>0&&b.x<W&&b.y<H);
 for(const p of pickups){if(!p.taken&&Math.hypot(p.x-player.x,p.y-player.y)<28){p.taken=true;if(p.type==='ammo'){player.ammo+=12;toast('Ammo pickup +12');}else{player.hp=Math.min(100,player.hp+25);toast('Medkit +25 health');}}}
 const zoneRadius=Math.max(180,630-elapsed*5.5), dist=Math.hypot(player.x-W/2,player.y-H/2);
 if(dist>zoneRadius)player.hp-=7*dt;
 $('health').textContent=Math.max(0,Math.ceil(player.hp));$('ammo').textContent=player.ammo;$('alive').textContent=1+bots.filter(b=>b.hp>0).length;
 if(online&&socket&&socket.readyState===1)socket.send(JSON.stringify({type:'state',x:player.x,y:player.y,name:profile.name,character:selectedChar}));
 if(player.hp<=0){finish(false,false);return;}
 if(bots.every(b=>b.hp<=0)){finish(true,false);return;}
}
function camera(){return{x:Math.max(0,Math.min(W-canvas.width,player.x-canvas.width/2)),y:Math.max(0,Math.min(H-canvas.height,player.y-canvas.height/2))};}
function draw(){
 ctx.clearRect(0,0,canvas.width,canvas.height);const cam=camera();
 ctx.fillStyle='#7f9e55';ctx.fillRect(0,0,canvas.width,canvas.height);
 // grass texture
 for(let x=-(cam.x%70);x<canvas.width;x+=70)for(let y=-(cam.y%70);y<canvas.height;y+=70){ctx.fillStyle=((Math.floor((x+cam.x)/70)+(Math.floor((y+cam.y)/70)))%2)?'#87a75b':'#83a158';ctx.fillRect(x,y,68,68);}
 // roads and ponds
 ctx.fillStyle='#b4ad7c';ctx.beginPath();ctx.moveTo(120-cam.x,450-cam.y);ctx.lineTo(520-cam.x,560-cam.y);ctx.lineTo(990-cam.x,120-cam.y);ctx.lineTo(1020-cam.x,150-cam.y);ctx.lineTo(550-cam.x,610-cam.y);ctx.lineTo(100-cam.x,490-cam.y);ctx.fill();
 ctx.fillStyle='#4b9aaf';ctx.beginPath();ctx.ellipse(1550-cam.x,350-cam.y,210,115,.3,0,Math.PI*2);ctx.fill();
 // safe zone
 const zr=Math.max(180,630-elapsed*5.5);ctx.save();ctx.strokeStyle='#c8ff47';ctx.lineWidth=4;ctx.setLineDash([14,9]);ctx.beginPath();ctx.arc(W/2-cam.x,H/2-cam.y,zr,0,Math.PI*2);ctx.stroke();ctx.restore();
 // buildings / cover
 for(let i=0;i<18;i++){let x=(180+(i*317)%1650)-cam.x,y=(120+(i*197)%1100)-cam.y;if(x<-90||y<-90||x>canvas.width+90||y>canvas.height+90)continue;ctx.fillStyle='#5a5143';ctx.fillRect(x,y,65,50);ctx.fillStyle='#c6b994';ctx.fillRect(x+5,y+5,55,40);ctx.fillStyle='#766b53';ctx.fillRect(x+24,y+18,18,14);}
 for(const p of pickups)if(!p.taken){const x=p.x-cam.x,y=p.y-cam.y;ctx.fillStyle=p.type==='ammo'?'#f5cf4f':'#f28b77';ctx.beginPath();ctx.arc(x,y,9,0,Math.PI*2);ctx.fill();ctx.fillStyle='#15232b';ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.fillText(p.type==='ammo'?'A':'+',x,y+4);}
 for(const b of bots)if(b.hp>0)drawFighter(b.x-cam.x,b.y-cam.y,b.angle,{color:b.color,accent:'#773d42'},b.hp);
 for(const id in others){const o=others[id];drawFighter(o.x-cam.x,o.y-cam.y,0,looks[o.character]||looks[0],100);ctx.fillStyle='white';ctx.font='12px sans-serif';ctx.textAlign='center';ctx.fillText(o.name||'Player',o.x-cam.x,o.y-cam.y-25);}
 drawFighter(player.x-cam.x,player.y-cam.y,player.angle,looks[selectedChar],player.hp,true);
 for(const q of bullets){ctx.fillStyle=q.owner==='player'?'#eaff7b':'#ff8b70';ctx.beginPath();ctx.arc(q.x-cam.x,q.y-cam.y,4,0,Math.PI*2);ctx.fill();}
 // compass
 ctx.fillStyle='#10212dcc';ctx.fillRect(canvas.width/2-55,8,110,24);ctx.fillStyle='#eaf3ed';ctx.font='bold 11px sans-serif';ctx.textAlign='center';ctx.fillText('N   •   '+Math.floor(elapsed)+'s   •   SAFE ZONE',canvas.width/2,24);
}
function drawFighter(x,y,a,look,hp,isPlayer=false){if(x<-35||y<-35||x>canvas.width+35||y>canvas.height+35)return;ctx.save();ctx.translate(x,y);ctx.rotate(a);ctx.fillStyle='#18242b';ctx.fillRect(-13,-10,27,20);ctx.fillStyle=look.color;ctx.beginPath();ctx.arc(0,0,13,0,Math.PI*2);ctx.fill();ctx.fillStyle=look.accent;ctx.fillRect(-7,-8,12,16);ctx.fillStyle='#d9e4df';ctx.fillRect(5,-4,23,8);ctx.restore();ctx.fillStyle='#2c3c32';ctx.fillRect(x-17,y-23,34,4);ctx.fillStyle=hp>55?'#baff5a':'#ff6b5f';ctx.fillRect(x-17,y-23,34*Math.max(0,hp/100),4);if(isPlayer){ctx.strokeStyle='#f5ffb0';ctx.lineWidth=2;ctx.beginPath();ctx.arc(x,y,20,0,Math.PI*2);ctx.stroke();}}
function finish(win,leave){
 if(!running)return;stopGame();if(!leave){profile.matches++;if(win){profile.wins++;earned+=100;profile.coins+=100;}else{earned+=25;profile.coins+=25;}save();}
 $('resultTitle').textContent=leave?'MATCH ABANDONED':win?'VICTORY ROYALE':'ELIMINATED';
 $('resultText').textContent=leave?'You left the match.':win?'All opponents eliminated. You own this island!':'You were knocked out. Drop again and try a new strategy.';
 $('earned').textContent=leave?0:earned;show('result');
}
$('reloadBtn').onclick=()=>{if(player){player.ammo=30;toast('Reloaded');}};
$('fireBtn').onpointerdown=e=>{e.preventDefault();mouse.down=true;};$('fireBtn').onpointerup=()=>mouse.down=false;$('fireBtn').onpointerleave=()=>mouse.down=false;
canvas.addEventListener('pointermove',e=>{const r=canvas.getBoundingClientRect();mouse.x=e.clientX-r.left;mouse.y=e.clientY-r.top;});
canvas.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'){mouse.down=true;const r=canvas.getBoundingClientRect();mouse.x=e.clientX-r.left;mouse.y=e.clientY-r.top;}});
window.addEventListener('pointerup',()=>mouse.down=false);
window.addEventListener('keydown',e=>{keys[e.key]=true;if([' ','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.key))e.preventDefault();if(e.key.toLowerCase()==='r'&&player)player.ammo=30;});
window.addEventListener('keyup',e=>keys[e.key]=false);
const stick=$('stick'),knob=$('stickKnob');let stickId=null;
stick.addEventListener('pointerdown',e=>{stickId=e.pointerId;stick.setPointerCapture(stickId);moveStick(e);});
stick.addEventListener('pointermove',e=>{if(e.pointerId===stickId)moveStick(e);});
function moveStick(e){const r=stick.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=(e.clientX-cx)/(r.width*.34),dy=(e.clientY-cy)/(r.height*.34),m=Math.hypot(dx,dy)||1;if(m>1){dx/=m;dy/=m;}joy.x=dx;joy.y=dy;knob.style.transform=`translate(${dx*24}px,${dy*24}px)`;}
function releaseStick(){stickId=null;joy.x=joy.y=0;knob.style.transform='translate(0,0)';}
stick.addEventListener('pointerup',releaseStick);stick.addEventListener('pointercancel',releaseStick);
updateUI();
})();