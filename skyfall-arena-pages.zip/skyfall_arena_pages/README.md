# Skyfall Arena — Free Web Game

A mobile-friendly, browser-playable 2D battle-royale-inspired prototype. It includes character selection, touch movement/fire controls, bots, a shrinking safe zone, pickups, coins, and a local demo profile.

## Publish free with GitHub Pages from an Android phone

1. Download `skyfall-arena-pages.zip` and extract it using your phone's Files app.
2. Sign in or create a free account at https://github.com/.
3. Open https://github.com/new and create a repository named `skyfall-arena`. Choose **Public**. You do not need to add a README there.
4. On the new repository page, tap **Add file** → **Upload files**.
5. Upload these files from the extracted folder into the repository root: `index.html`, `style.css`, `game.js`, `.nojekyll`, and `README.md`. If your file picker hides `.nojekyll`, skip that file; it is optional.
6. Tap **Commit changes**.
7. In the repository, open **Settings** → **Pages**.
8. Under **Build and deployment**, choose **Deploy from a branch**. Select branch **main** and folder **/(root)**, then tap **Save**.
9. Wait a few minutes. Return to **Settings → Pages**; GitHub will show the public site URL, usually `https://YOUR-USERNAME.github.io/skyfall-arena/`.
10. Open that URL on your phone and tap **PLAY SOLO**. Use the left touch pad to move and FIRE to shoot. The browser saves the demo profile/coins on that device only.

## Notes
- Hosting the web game on GitHub Pages is free for a public repository under GitHub's published Pages terms.
- This is a local single-player prototype with bots, not real online multiplayer. The Online button requires a separately deployed WebSocket server and will not work just from GitHub Pages.
- The profile is local to the browser/device; it is not real login or cloud storage. Do not enter sensitive information.
- This prototype is not affiliated with Garena Free Fire and does not copy its assets.
